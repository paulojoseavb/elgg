define( function ( require ) {

	"use strict";

	return {
		app_slug : 'a-s-c-a-p-i-e',
		wp_ws_url : 'http://174.138.47.193/wp-appkit-api/a-s-c-a-p-i-e',
		wp_url : 'http://174.138.47.193',
		theme : 'q-android',
		version : '1.0',
		app_title : 'Ascapie',
		app_platform : 'android',
		gmt_offset : -3,
		debug_mode : 'off',
		auth_key : '8m+~B:B!$DD:8E]fyenOu7gI*Wnzg3*o@8Bg0{EIBoJB7$k(fR~&b/zK$lKK(=o ',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
